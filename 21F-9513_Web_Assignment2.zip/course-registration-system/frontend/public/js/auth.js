// Login and registration scripts
document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const rollNumber = document.getElementById('rollNumber').value;
    fetchData('/api/auth/login', 'POST', { rollNumber }).then(data => {
        if (data.success) {
            window.location.href = '/student/dashboard';
        } else {
            alert('Login failed');
        }
    });
});