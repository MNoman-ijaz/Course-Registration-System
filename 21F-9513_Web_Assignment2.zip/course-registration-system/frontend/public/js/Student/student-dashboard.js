// Track selected courses
let selectedCourses = [];
let registeredCourses = [];

// Load initial data
document.addEventListener('DOMContentLoaded', () => {
    const rollNumber = localStorage.getItem('rollNumber');
    if (!rollNumber) {
        alert('Please log in first.');
        window.location.href = 'student-login.html';
        return;
    }

    // Fetch registered courses for the student
    fetchRegisteredCourses(rollNumber);

    // Fetch departments for the filter dropdown
    fetchDepartments();

    // Add event listener for fetching available courses
    document.getElementById('fetch-courses-btn').addEventListener('click', () => {
        fetchAvailableCourses();
    });

    // Add event listener for applying the filter
    document.getElementById('apply-filter-btn').addEventListener('click', () => {
        const selectedDepartment = document.getElementById('department-filter').value;
        filterCoursesByDepartment(selectedDepartment);
    });
});

// Fetch available courses from the backend
function fetchAvailableCourses() {
    fetch('http://localhost:5000/api/courses')
        .then(response => response.json())
        .then(data => {
            renderAvailableCourses(data);
        })
        .catch(error => {
            console.error('Error fetching available courses:', error);
        });
}

// Render available courses
function renderAvailableCourses(courses) {
    const availableCoursesList = document.getElementById('available-courses-list');
    availableCoursesList.innerHTML = '';

    if (courses.length === 0) {
        availableCoursesList.innerHTML = '<p>No courses available.</p>';
        return;
    }

    courses.forEach(course => {
        const courseElement = document.createElement('div');
        courseElement.className = 'course-item';
        courseElement.innerHTML = `
            <h3>${course.name}</h3>
            <p>Department: ${course.department}</p>
            <p>Level: ${course.level}</p>
            <p>Seats: ${course.availableSeats}</p>
            <p>Schedule: ${course.schedule}</p>
            <div class="course-actions">
                ${course.availableSeats > 0 
                    ? `<button onclick="registerCourse('${course._id}')">Register</button>` 
                    : '<p>No seats available</p>'
                }
                <button class="subscribe-btn" onclick="subscribeToCourse('${course._id}')">Subscribe</button>
            </div>
        `;
        availableCoursesList.appendChild(courseElement);
    });
}

// Fetch registered courses for the student
function fetchRegisteredCourses(rollNumber) {
    fetch(`http://localhost:5000/api/student/registered-courses?rollNumber=${rollNumber}`)
        .then(response => response.json())
        .then(data => {
            if (data.registeredCourses) {
                renderRegisteredCourses(data.registeredCourses);
            } else {
                console.error('No registered courses found:', data);
            }
        })
        .catch(error => {
            console.error('Error fetching registered courses:', error);
        });
}

// Render registered courses to the DOM
function renderRegisteredCourses(courses) {
    const registeredCoursesList = document.getElementById('registered-courses-list');
    registeredCoursesList.innerHTML = '';

    if (courses.length === 0) {
        registeredCoursesList.innerHTML = '<p>No courses registered.</p>';
        return;
    }

    courses.forEach(course => {
        const courseItem = document.createElement('div');
        courseItem.className = 'course-item';
        courseItem.innerHTML = `
            <h3>${course.name}</h3>
            <p>Department: ${course.department}</p>
            <p>Level: ${course.level}</p>
            <p>Schedule: ${course.schedule}</p>
            <button onclick="dropCourse('${course._id}')">Drop</button>
        `;
        registeredCoursesList.appendChild(courseItem);
    });
}

// Register for a course
function registerCourse(courseId) {
    const rollNumber = localStorage.getItem('rollNumber');
    if (!rollNumber) {
        alert('Please log in first.');
        return;
    }

    fetch('http://localhost:5000/api/student/register-course', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ rollNumber, courseId }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Course registered successfully') {
            alert('Course registered successfully');
            fetchRegisteredCourses(rollNumber); // Refresh the registered courses list
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error registering course:', error);
    });
}

// Drop a course
// Drop a course
function dropCourse(courseId) {
    const rollNumber = localStorage.getItem('rollNumber');
    if (!rollNumber) {
        alert('Please log in first.');
        return;
    }

    fetch('http://localhost:5000/api/student/drop-course', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ rollNumber, courseId }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Course dropped successfully') {
            alert('Course dropped successfully');
            fetchRegisteredCourses(rollNumber); // Refresh the registered courses list
            fetchAvailableCourses(); // Refresh the available courses list
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error dropping course:', error);
    });
}
// Fetch departments for the filter dropdown (from available courses)
function fetchDepartments() {
    fetch('http://localhost:5000/api/courses')
        .then(response => response.json())
        .then(data => {
            console.log('Fetched Courses:', data); // Log fetched data

            // Filter courses with availableSeats > 0
            const availableCourses = data.filter(course => course.availableSeats > 0);
            console.log('Available Courses:', availableCourses); // Log available courses

            // Get unique departments from available courses
            const departments = [...new Set(availableCourses.map(course => course.department))];
            console.log('Unique Departments (Available Courses):', departments); // Log unique departments

            // Populate the dropdown
            populateDepartmentFilter(departments);
        })
        .catch(error => {
            console.error('Error fetching departments:', error);
        });
}

// Populate the department filter dropdown
function populateDepartmentFilter(departments) {
    const departmentFilter = document.getElementById('department-filter');
    departmentFilter.innerHTML = '<option value="all">All Departments</option>'; // Reset dropdown

    departments.forEach(department => {
        if (department) { // Ensure department is not null or undefined
            const option = document.createElement('option');
            option.value = department;
            option.textContent = department;
            departmentFilter.appendChild(option);
        }
    });

    console.log('Dropdown populated with:', departments); // Log populated departments
}

// Filter available courses by department
function filterCoursesByDepartment(department) {
    fetch('http://localhost:5000/api/courses')
        .then(response => response.json())
        .then(data => {
            console.log('Fetched Courses:', data); // Log fetched data

            // Filter available courses (availableSeats > 0)
            const availableCourses = data.filter(course => course.availableSeats > 0);
            console.log('Available Courses:', availableCourses); // Log available courses

            // Filter by selected department
            const filteredCourses = department === 'all' 
                ? availableCourses 
                : availableCourses.filter(course => course.department === department);

            console.log('Filtered Courses:', filteredCourses); // Log filtered courses

            // Render the filtered courses
            renderAvailableCourses(filteredCourses);
        })
        .catch(error => {
            console.error('Error filtering courses:', error);
        });
}
// Subscribe to a course for seat availability notifications
function subscribeToCourse(courseId) {
    const rollNumber = localStorage.getItem('rollNumber');
    if (!rollNumber) {
        alert('Please log in first.');
        return;
    }

    fetch('http://localhost:5000/api/student/subscribe', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ rollNumber, courseId }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Subscribed successfully') {
            alert('You will be notified when a seat becomes available.');
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error subscribing to course:', error);
    });
}
// Check for seat availability notifications
// Check for seat availability notifications
function checkNotifications() {
    const rollNumber = localStorage.getItem('rollNumber');
    if (!rollNumber) {
        alert('Please log in first.');
        return;
    }

    fetch(`http://localhost:5000/api/student/check-notifications?rollNumber=${rollNumber}`)
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Seat available') {
                // Display a notification for each available course
                data.courses.forEach(course => {
                    showNotification(`A seat is now available for ${course.name} (${course.department}).`);
                });
            }
        })
        .catch(error => {
            console.error('Error checking notifications:', error);
        });
}

// Periodically check for notifications (every 10 seconds)
setInterval(checkNotifications, 10000); // 10 seconds