// Sample data (replace with database integration)
let courses = [];
let students = [];

// Add Course
document.getElementById('course-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const courseName = document.getElementById('course-name').value;
    const department = document.getElementById('department').value;
    const level = document.getElementById('level').value;
    const availableSeats = document.getElementById('available-seats').value;
    const prerequisites = document.getElementById('prerequisites').value;

    const course = {
        id: courses.length + 1,
        name: courseName,
        department,
        level,
        seats: availableSeats,
        prerequisites: prerequisites.split(',').map(p => p.trim())
    };

    courses.push(course);
    displayCourses();
    document.getElementById('course-form').reset();
});

// Fetch all courses from the backend
function fetchAllCourses() {
    fetch('http://localhost:5000/api/courses')
        .then(response => response.json())
        .then(data => {
            renderAllCourses(data);
        })
        .catch(error => {
            console.error('Error fetching all courses:', error);
        });
}

// Render all courses to the DOM
function renderAllCourses(courses) {
    const coursesList = document.getElementById('courses-list');
    coursesList.innerHTML = '';

    courses.forEach(course => {
        const courseItem = document.createElement('div');
        courseItem.className = 'course-item';
        courseItem.innerHTML = `
            <p><strong>${course.name}</strong> - ${course.department} (${course.level})</p>
            <p>Seats Available: ${course.availableSeats}</p>
            <p>Schedule: ${course.schedule}</p>
            <button onclick="updateCourse('${course._id}')">Update</button>
            <button onclick="deleteCourse('${course._id}')">Delete</button>
        `;
        coursesList.appendChild(courseItem);
    });
}

// Fetch all courses on page load
fetchAllCourses();

// Display Courses
function displayCourses() {
    const courseList = document.getElementById('course-list');
    courseList.innerHTML = courses.map(course => `
        <div class="course-item">
            <div>
                <strong>${course.name}</strong> (${course.department}, Level ${course.level})<br>
                Seats: ${course.seats}, Prerequisites: ${course.prerequisites.join(', ')}
            </div>
            <button onclick="deleteCourse(${course.id})">Delete</button>
        </div>
    `).join('');
}

// Delete Course
function deleteCourse(id) {
    courses = courses.filter(course => course.id !== id);
    displayCourses();
}

// Update Seats
document.getElementById('seat-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const courseId = document.getElementById('course-id').value;
    const newSeats = document.getElementById('new-seats').value;

    const course = courses.find(course => course.id == courseId);
    if (course) {
        course.seats = newSeats;
        displayCourses();
    }
    document.getElementById('seat-form').reset();
});

// Generate Reports
function generateReport(type) {
    let output = '';
    switch (type) {
        case 'students-per-course':
            output = courses.map(course => `${course.name}: ${students.filter(student => student.courses.includes(course.id)).length} students`).join('<br>');
            break;
        case 'courses-with-seats':
            output = courses.filter(course => course.seats > 0).map(course => `${course.name}: ${course.seats} seats`).join('<br>');
            break;
        case 'students-missing-prerequisites':
            output = students.filter(student => !student.prerequisitesCompleted).map(student => student.name).join('<br>');
            break;
    }
    document.getElementById('report-output').innerHTML = output;
}
// Open Override Modal

      // Fetch data from the backend
 // Fetch data from the backend
// Base URL for the backend API
// Base URL for the backend API
const BASE_URL = 'http://localhost:5000';

// Fetch data from the backend
async function fetchData() {
    try {
        const response = await fetch(`${BASE_URL}/api/admin/student-management-data`);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching data:', error);
        alert('Failed to fetch data. Please try again.');
        return { students: [], courses: [] }; // Return empty data in case of error
    }
}

// Populate dropdowns
async function populateDropdowns() {
    const data = await fetchData();

    // Populate student dropdown
    const studentSelect = document.getElementById('studentSelect');
    studentSelect.innerHTML = data.students.map(student =>
        `<option value="${student._id}">${student.rollNumber}</option>`
    ).join('');

    // Populate course dropdown
    const courseSelect = document.getElementById('courseSelect');
    courseSelect.innerHTML = data.courses.map(course =>
        `<option value="${course._id}">${course.name}</option>`
    ).join('');
}

// Open Override Modal
function openOverrideModal() {
    document.getElementById('overrideModal').style.display = 'flex';
    populateDropdowns(); // Populate dropdowns when modal opens
}

// Close Override Modal
function closeOverrideModal() {
    document.getElementById('overrideModal').style.display = 'none';
}

// Confirm Override Registration
async function confirmOverride() {
    const studentId = document.getElementById('studentSelect').value;
    const courseId = document.getElementById('courseSelect').value;

    try {
        const response = await fetch(`${BASE_URL}/api/admin/override-registration`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ studentId, courseId })
        });

        const result = await response.json();
        if (response.ok) {
            alert('Override registration successful!');
            closeOverrideModal();
        } else {
            alert('Error: ' + result.message);
        }
    } catch (error) {
        console.error('Error during override registration:', error);
        alert('Failed to override registration. Please try again.');
    }
}

// Add event listener to open modal
document.getElementById('openModalButton').addEventListener('click', openOverrideModal);
document.getElementById('confirmOverrideButton').addEventListener('click', confirmOverride);
document.getElementById('cancelButton').addEventListener('click', closeOverrideModal);