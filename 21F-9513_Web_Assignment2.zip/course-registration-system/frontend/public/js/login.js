document.addEventListener("DOMContentLoaded", () => {
    // DOM elements
    const welcomeSection = document.querySelector(".welcome-section")
    const studentLogin = document.getElementById("student-login")
    const adminLogin = document.getElementById("admin-login")
    const studentLoginForm = document.getElementById("student-login-form")
    const adminLoginForm = document.getElementById("admin-login-form")
  
    // Show login form based on user type
    window.showLoginForm = (userType) => {
      welcomeSection.style.display = "none"
  
      if (userType === "student") {
        studentLogin.style.display = "block"
        adminLogin.style.display = "none"
      } else if (userType === "admin") {
        adminLogin.style.display = "block"
        studentLogin.style.display = "none"
      }
    }
  
    // Hide login form and show welcome section
    window.hideLoginForm = () => {
      studentLogin.style.display = "none"
      adminLogin.style.display = "none"
      welcomeSection.style.display = "block"
    }
  
    // Handle student login form submission
    studentLoginForm.addEventListener("submit", (e) => {
      e.preventDefault()
      const rollNumber = document.getElementById("roll-number").value
  
      // In a real application, you would validate the roll number with the server
      // For demo purposes, we'll just redirect to the student dashboard
      localStorage.setItem("userType", "student")
      localStorage.setItem("rollNumber", rollNumber)
      window.location.href = "student-dashboard.html"
    })
  
    // Handle admin login form submission
    adminLoginForm.addEventListener("submit", (e) => {
      e.preventDefault()
      const username = document.getElementById("username").value
      const password = document.getElementById("password").value
  
      // In a real application, you would validate the credentials with the server
      // For demo purposes, we'll just redirect to the admin dashboard if username is "admin" and password is "admin"
      if (username === "admin" && password === "admin") {
        localStorage.setItem("userType", "admin")
        localStorage.setItem("adminName", username)
        window.location.href = "admin-dashboard.html"
      } else {
        alert("Invalid credentials. Please try again.")
      }
    })
  })
  
  