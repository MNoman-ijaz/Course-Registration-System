const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');

router.post('/login', adminController.login);
router.post('/courses', adminController.addCourse);
router.put('/courses/:id', adminController.updateCourse);
router.delete('/courses/:id', adminController.deleteCourse);
router.get('/courses', adminController.fetchCourses);
router.get('/student-management-data', adminController.fetchStudentManagementData);
router.post('/override-registration', adminController.overrideRegistration);

module.exports = router;