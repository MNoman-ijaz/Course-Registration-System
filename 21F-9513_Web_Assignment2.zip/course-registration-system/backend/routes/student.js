const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');

router.post('/login', studentController.login);
router.post('/register-course', studentController.registerCourse);
router.post('/drop-course', studentController.dropCourse);
router.get('/registered-courses', studentController.fetchRegisteredCourses);
router.post('/subscribe', studentController.subscribe);

module.exports = router;