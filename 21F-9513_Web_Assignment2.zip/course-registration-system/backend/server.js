const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Serve static files from the "frontend/public" directory
app.use(express.static(path.join(__dirname, 'frontend', 'public')));

// MongoDB connection
const mongoURI = 'mongodb+srv://noman:3smcjnA6W0pvyiXD@cluster0.nfvdd7a.mongodb.net/course-data?retryWrites=true&w=majority&appName=Cluster0';
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));

// Define schemas
const StudentSchema = new mongoose.Schema({
    rollNumber: String,
    selectedCourses: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }],
    subscribedCourses: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }] // Add this line
});
const AdminSchema = new mongoose.Schema({
    username: String,
    password: String
});

const CourseSchema = new mongoose.Schema({
    name: String,
    department: String,
    level: String,
    availableSeats: Number,
    schedule: String,
    prerequisites: [String],
    registeredStudents: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Student' }], // Track registered students
});


const Student = mongoose.model('Student', StudentSchema);
const Admin = mongoose.model('Admin', AdminSchema);
const Course = mongoose.model('Course', CourseSchema);

// Routes

// Admin Login
app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const admin = await Admin.findOne({ username, password });
        if (admin) {
            res.json({ message: 'Admin login successful', admin });
        } else {
            res.status(401).json({ message: 'Invalid username or password' });
        }
    } catch (error) {
        console.error('Error during admin login:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Student Login
app.post('/api/student/login', async (req, res) => {
    const { rollNumber } = req.body;
    try {
        const student = await Student.findOne({ rollNumber });
        if (student) {
            res.json({ message: 'Student login successful', student });
        } else {
            res.status(400).json({ message: 'Invalid roll number' });
        }
    } catch (error) {
        console.error('Error during student login:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Add Course (Admin)
app.post('/api/courses', async (req, res) => {
    const { name, department, level, availableSeats, schedule, prerequisites } = req.body;
    try {
        const newCourse = new Course({ name, department, level, availableSeats, schedule, prerequisites });
        await newCourse.save();
        res.status(201).json({ message: 'Course added successfully', course: newCourse });
    } catch (error) {
        console.error('Error adding course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Update Course (Admin)
app.put('/api/courses/:id', async (req, res) => {
    const { id } = req.params;
    const { name, department, level, availableSeats, schedule, prerequisites } = req.body;
    try {
        const updatedCourse = await Course.findByIdAndUpdate(
            id,
            { name, department, level, availableSeats, schedule, prerequisites },
            { new: true }
        );
        if (updatedCourse) {
            res.json({ message: 'Course updated successfully', course: updatedCourse });
        } else {
            res.status(404).json({ message: 'Course not found' });
        }
    } catch (error) {
        console.error('Error updating course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Delete Course (Admin)
app.delete('/api/courses/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const deletedCourse = await Course.findByIdAndDelete(id);
        if (deletedCourse) {
            res.json({ message: 'Course deleted successfully' });
        } else {
            res.status(404).json({ message: 'Course not found' });
        }
    } catch (error) {
        console.error('Error deleting course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Fetch All Courses (Admin)
app.get('/api/courses', async (req, res) => {
    try {
        const courses = await Course.find();
        res.json(courses);
    } catch (error) {
        console.error('Error fetching courses:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Fetch All Courses (Student Dashboard)
app.get('/api/courses', async (req, res) => {
    try {
        const courses = await Course.find();
        res.json(courses);
    } catch (error) {
        console.error('Error fetching courses:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.get('/api/courses', async (req, res) => {
    try {
        const courses = await Course.find().populate('registeredStudents');
        res.json(courses);
    } catch (error) {
        console.error('Error fetching courses:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.get('/api/students', async (req, res) => {
    try {
        const students = await Student.find();
        res.json(students);
    } catch (error) {
        console.error('Error fetching students:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Register Course (Student)
app.post('/api/student/register-course', async (req, res) => {
    const { rollNumber, courseId } = req.body;

    try {
        const student = await Student.findOne({ rollNumber });
        const course = await Course.findById(courseId);

        if (!student || !course) {
            return res.status(404).json({ message: 'Student or course not found' });
        }

        // Check if the course is already registered
        if (student.selectedCourses.includes(courseId)) {
            return res.status(400).json({ message: 'Course already registered' });
        }

        // Check if seats are available
        if (course.availableSeats <= 0) {
            return res.status(400).json({ message: 'No seats available' });
        }

        // Decrement available seats
        course.availableSeats -= 1;

        // Add the student to the course's registeredStudents array
        course.registeredStudents.push(student._id);

        // Add the course to the student's selected courses
        student.selectedCourses.push(courseId);

        await course.save();
        await student.save();

        res.json({ message: 'Course registered successfully', course });
    } catch (error) {
        console.error('Error registering course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Drop Course (Student)
app.post('/api/student/drop-course', async (req, res) => {
    const { rollNumber, courseId } = req.body;

    try {
        const student = await Student.findOne({ rollNumber });
        const course = await Course.findById(courseId);

        if (!student || !course) {
            return res.status(404).json({ message: 'Student or course not found' });
        }

        // Remove the student from the course's registeredStudents array
        course.registeredStudents = course.registeredStudents.filter(id => id.toString() !== student._id.toString());

        // Increment available seats
        course.availableSeats += 1;

        // Remove the course from the student's selected courses
        student.selectedCourses = student.selectedCourses.filter(id => id.toString() !== courseId);

        await course.save();
        await student.save();

        res.json({ message: 'Course dropped successfully', course });
    } catch (error) {
        console.error('Error dropping course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Fetch Registered Courses (Student)
app.get('/api/student/registered-courses', async (req, res) => {
    const { rollNumber } = req.query;

    try {
        const student = await Student.findOne({ rollNumber }).populate('selectedCourses');
        if (!student) {
            return res.status(404).json({ message: 'Student not found' });
        }

        res.json({ registeredCourses: student.selectedCourses });
    } catch (error) {
        console.error('Error fetching registered courses:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Student Management: Fetch Students and Available Courses
app.get('/api/admin/student-management-data', async (req, res) => {
    try {
        const students = await Student.find({}, '_id rollNumber');
        const courses = await Course.find({ availableSeats: { $gt: 0 } }, '_id name');
        res.json({ students, courses });
    } catch (error) {
        console.error('Error fetching student management data:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Student Management: Override Registration
app.post('/api/admin/override-registration', async (req, res) => {
    const { studentId, courseId } = req.body;

    try {
        const student = await Student.findById(studentId);
        const course = await Course.findById(courseId);

        if (!student || !course) {
            return res.status(404).json({ message: 'Student or course not found' });
        }

        // Check if the student is already registered for the course
        if (student.selectedCourses.includes(courseId)) {
            return res.status(400).json({ message: 'Student is already registered for this course' });
        }

        // Check if seats are available
        if (course.availableSeats <= 0) {
            return res.status(400).json({ message: 'No seats available' });
        }

        // Decrement available seats
        course.availableSeats -= 1;

        // Add the student to the course's registeredStudents array
        course.registeredStudents.push(student._id);

        // Add the course to the student's selected courses
        student.selectedCourses.push(courseId);

        await course.save();
        await student.save();

        res.json({ message: 'Override registration successful', course });
    } catch (error) {
        console.error('Error overriding registration:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Subscribe to a course for seat availability notifications
app.post('/api/student/subscribe', async (req, res) => {
    const { rollNumber, courseId } = req.body;

    try {
        const student = await Student.findOne({ rollNumber });
        const course = await Course.findById(courseId);

        if (!student || !course) {
            return res.status(404).json({ message: 'Student or course not found' });
        }

        // Check if the student is already subscribed
        if (student.subscribedCourses.includes(courseId)) {
            return res.status(400).json({ message: 'Already subscribed to this course' });
        }

        // Add the course to the student's subscribed courses
        student.subscribedCourses.push(courseId);
        await student.save();

        res.json({ message: 'Subscribed successfully' });
    } catch (error) {
        console.error('Error subscribing to course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});