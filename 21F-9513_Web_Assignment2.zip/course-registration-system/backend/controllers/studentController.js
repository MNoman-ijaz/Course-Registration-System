const Student = require('../models/Student');
const Course = require('../models/Course');

exports.login = async (req, res) => {
    const { rollNumber } = req.body;
    try {
        const student = await Student.findOne({ rollNumber });
        if (student) {
            res.json({ message: 'Student login successful', student });
        } else {
            res.status(400).json({ message: 'Invalid roll number' });
        }
    } catch (error) {
        console.error('Error during student login:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.registerCourse = async (req, res) => {
    const { rollNumber, courseId } = req.body;

    try {
        const student = await Student.findOne({ rollNumber });
        const course = await Course.findById(courseId);

        if (!student || !course) {
            return res.status(404).json({ message: 'Student or course not found' });
        }

        if (student.selectedCourses.includes(courseId)) {
            return res.status(400).json({ message: 'Course already registered' });
        }

        if (course.availableSeats <= 0) {
            return res.status(400).json({ message: 'No seats available' });
        }

        course.availableSeats -= 1;
        course.registeredStudents.push(student._id);
        student.selectedCourses.push(courseId);

        await course.save();
        await student.save();

        res.json({ message: 'Course registered successfully', course });
    } catch (error) {
        console.error('Error registering course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.dropCourse = async (req, res) => {
    const { rollNumber, courseId } = req.body;

    try {
        const student = await Student.findOne({ rollNumber });
        const course = await Course.findById(courseId);

        if (!student || !course) {
            return res.status(404).json({ message: 'Student or course not found' });
        }

        course.registeredStudents = course.registeredStudents.filter(id => id.toString() !== student._id.toString());
        course.availableSeats += 1;
        student.selectedCourses = student.selectedCourses.filter(id => id.toString() !== courseId);

        await course.save();
        await student.save();

        res.json({ message: 'Course dropped successfully', course });
    } catch (error) {
        console.error('Error dropping course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.fetchRegisteredCourses = async (req, res) => {
    const { rollNumber } = req.query;

    try {
        const student = await Student.findOne({ rollNumber }).populate('selectedCourses');
        if (!student) {
            return res.status(404).json({ message: 'Student not found' });
        }

        res.json({ registeredCourses: student.selectedCourses });
    } catch (error) {
        console.error('Error fetching registered courses:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.subscribe = async (req, res) => {
    const { rollNumber, courseId } = req.body;

    try {
        const student = await Student.findOne({ rollNumber });
        const course = await Course.findById(courseId);

        if (!student || !course) {
            return res.status(404).json({ message: 'Student or course not found' });
        }

        if (student.subscribedCourses.includes(courseId)) {
            return res.status(400).json({ message: 'Already subscribed to this course' });
        }

        student.subscribedCourses.push(courseId);
        await student.save();

        res.json({ message: 'Subscribed successfully' });
    } catch (error) {
        console.error('Error subscribing to course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};