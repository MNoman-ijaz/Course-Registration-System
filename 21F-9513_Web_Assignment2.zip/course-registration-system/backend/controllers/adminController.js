const Admin = require('../models/Admin');
const Course = require('../models/Course');
const Student = require('../models/Student');

exports.login = async (req, res) => {
    const { username, password } = req.body;
    try {
        const admin = await Admin.findOne({ username, password });
        if (admin) {
            res.json({ message: 'Admin login successful', admin });
        } else {
            res.status(401).json({ message: 'Invalid username or password' });
        }
    } catch (error) {
        console.error('Error during admin login:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.addCourse = async (req, res) => {
    const { name, department, level, availableSeats, schedule, prerequisites } = req.body;
    try {
        const newCourse = new Course({ name, department, level, availableSeats, schedule, prerequisites });
        await newCourse.save();
        res.status(201).json({ message: 'Course added successfully', course: newCourse });
    } catch (error) {
        console.error('Error adding course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.updateCourse = async (req, res) => {
    const { id } = req.params;
    const { name, department, level, availableSeats, schedule, prerequisites } = req.body;
    try {
        const updatedCourse = await Course.findByIdAndUpdate(
            id,
            { name, department, level, availableSeats, schedule, prerequisites },
            { new: true }
        );
        if (updatedCourse) {
            res.json({ message: 'Course updated successfully', course: updatedCourse });
        } else {
            res.status(404).json({ message: 'Course not found' });
        }
    } catch (error) {
        console.error('Error updating course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.deleteCourse = async (req, res) => {
    const { id } = req.params;
    try {
        const deletedCourse = await Course.findByIdAndDelete(id);
        if (deletedCourse) {
            res.json({ message: 'Course deleted successfully' });
        } else {
            res.status(404).json({ message: 'Course not found' });
        }
    } catch (error) {
        console.error('Error deleting course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.fetchCourses = async (req, res) => {
    try {
        const courses = await Course.find();
        res.json(courses);
    } catch (error) {
        console.error('Error fetching courses:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.fetchStudentManagementData = async (req, res) => {
    try {
        const students = await Student.find({}, '_id rollNumber');
        const courses = await Course.find({ availableSeats: { $gt: 0 } }, '_id name');
        res.json({ students, courses });
    } catch (error) {
        console.error('Error fetching student management data:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

exports.overrideRegistration = async (req, res) => {
    const { studentId, courseId } = req.body;

    try {
        const student = await Student.findById(studentId);
        const course = await Course.findById(courseId);

        if (!student || !course) {
            return res.status(404).json({ message: 'Student or course not found' });
        }

        if (student.selectedCourses.includes(courseId)) {
            return res.status(400).json({ message: 'Student is already registered for this course' });
        }

        if (course.availableSeats <= 0) {
            return res.status(400).json({ message: 'No seats available' });
        }

        course.availableSeats -= 1;
        course.registeredStudents.push(student._id);
        student.selectedCourses.push(courseId);

        await course.save();
        await student.save();

        res.json({ message: 'Override registration successful', course });
    } catch (error) {
        console.error('Error overriding registration:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};