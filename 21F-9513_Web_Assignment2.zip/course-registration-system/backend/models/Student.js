const mongoose = require('mongoose');

const StudentSchema = new mongoose.Schema({
    rollNumber: String,
    selectedCourses: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }],
    subscribedCourses: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }]
});

module.exports = mongoose.model('Student', StudentSchema);