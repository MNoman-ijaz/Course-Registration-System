const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
    name: String,
    department: String,
    level: String,
    availableSeats: Number,
    schedule: [
        {
            day: String,
            time: String,
        },
    ],
    prerequisites: [String],
});

module.exports = mongoose.model('Course', courseSchema);